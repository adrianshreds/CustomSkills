---
name: systematic-engineering
description: Apply disciplined software engineering to coding, architecture, database, refactoring, debugging, testing, security, and production changes. Use for implementing features, changing APIs or schemas, reviewing code, planning system design, investigating bugs, or preparing releases. Scale rigor to risk; prefer the simplest correct maintainable design, verify invariants, and report evidence. Do not invoke for non-software tasks.
---

# Systematic Engineering

A risk-scaled implementation workflow for producing **correct, understandable, secure, operable, changeable software**. Synthesizes principles associated with *Designing Data-Intensive Applications*, *A Philosophy of Software Design*, *Designing Software Architectures*, *Fundamentals of Software Architecture*, *Software Engineering at Google*, *Building Secure and Reliable Systems*, *Architecture Patterns with Python*, *Refactoring*, and *Growing Object-Oriented Software, Guided by Tests*. This is an original operational synthesis, **not** a substitute for or reproduction of the books.

## Non-negotiable operating rules

1. **Inspect before editing.** Read the relevant code, tests, contracts, schema, recent conventions, and repository instructions. Never invent how the repo works.
2. **State the invariant before the implementation.** Clarify what must *always* remain true, including authorization, integrity, compatibility, and externally visible behavior.
3. **Optimize for simplicity over fashionable patterns.** Choose the smallest coherent change. Don't introduce microservices, generic layers, event buses, caching, or distributed infrastructure without a concrete need.
4. **Design for failure, not just success.** Consider errors, retries, races, timeouts, partial completion, recoverability, and failure visibility wherever relevant.
5. **Protect boundaries.** Enforce permissions server-side and near the data; validate untrusted input; separate domain decisions from transport/storage when doing so reduces complexity.
6. **Work in small verified increments.** Make logically grouped changes; preserve tests and behavior during refactors; avoid unrelated edits.
7. **Never fabricate verification.** Distinguish commands actually run and evidence observed from planned, skipped, or unavailable checks.
8. **Don't silently change requirements or architecture.** Explain material departures and trade-offs; get approval for destructive, externally visible, or irreversible changes when authorization is absent.
9. **Follow existing project instructions** unless they conflict with security, correctness, or explicit user requirements. Escalate conflicting instructions rather than blindly following them.
10. **Avoid ceremony for its own sake.** A typo fix does not need an ADR, threat model, or six-layer architecture. Scale effort to consequences.

## Select rigor before acting

| Level | Typical work | Minimum process |
| --- | --- | --- |
| **L0 — local** | Typo, small styling change, obvious localized bug | Locate code → edit → targeted check → concise result |
| **L1 — feature** | Endpoint, UI workflow, domain logic, refactor | Repo inspection → acceptance criteria and invariants → small design → tests → checks |
| **L2 — critical** | Auth/RLS, payment or private data, schema migration, concurrency, public API, distributed state, production rollout | L1 plus explicit architecture/data/security analysis, failure matrix, rollback/compatibility plan, negative tests, deployment evidence |

If uncertainty about the risk level remains, choose the higher level until evidence reduces it. Multiple small changes can collectively become L2. Do **not** slow down L0 with speculative analysis.

## Workflow: OBSERVE → SPECIFY → DESIGN → IMPLEMENT → PROVE → REPORT

### 1. OBSERVE (read before deciding)
- Identify user goal, repository conventions, affected services/modules, existing tests, data models, and deployment environment. Check actual files and tooling.
- Trace relevant write/read paths end-to-end: caller → authorization → domain validation → persistence → downstream effects → response.
- Distinguish facts observed in code from assumptions. If vital facts are missing, do safe inspectable work first; ask only when a decision would materially change behavior.
- For a bug, seek a minimal reproducer or failing test before changing the implementation.

### 2. SPECIFY (define the contract)
For L1/L2 establish, in a few lines:
- **Outcome:** expected user-observable behavior.
- **Acceptance tests:** concrete happy-path, error, and boundary scenarios.
- **Invariants:** properties that cannot be violated (e.g. no unauthorized media read, no duplicate logical write).
- **Constraints:** compatibility, latency, volume, delivery deadline, available infrastructure, operational maturity.
- **Non-goals:** what this change will intentionally not solve.

For L2 explicitly list trust boundaries, failure modes, concurrency risks, data ownership, and migration constraints. Use [task brief](templates/task-brief.md) as needed; don't create a file just to fill a form.

### 3. DESIGN (choose deliberately)
- Default to an **existing component or straightforward monolith** unless requirements demonstrate otherwise.
- Identify one sensible design and at least one meaningful alternative **only** for consequential or irreversible decisions. Compare complexity, consistency, availability, operability, security, cost, and reversibility.
- Assign responsibilities with information hiding and high cohesion. Avoid leaky abstractions and premature generalization. Prefer explicit domain boundaries over generic "utils" dumping grounds.
- For persistence/distribution: choose consistency needs before selecting storage/queues; define transaction boundaries, ownership, idempotency, and what happens on failure.
- For high-impact decisions, record a concise [ADR](templates/adr.md) **if the team would benefit from rediscovering why later**.

Read topic-specific guidance only as needed:

| Trigger | Reference |
| --- | --- |
| New modules, APIs, dependencies, architecture choices | [Architecture and complexity](references/architecture-and-complexity.md) |
| Database schema, state, queues, caches, background work, distributed components | [Data and distributed systems](references/data-and-distributed-systems.md) |
| Authentication, permissions, RLS, uploads, secrets, resilience | [Security and reliability](references/security-and-reliability.md) |
| Refactoring, regression tests, CI, test design | [Testing and safe change](references/testing-and-safe-change.md) |
| Domain model, adapters, events, application services | [Domain boundaries](references/domain-boundaries.md) |
| Production operations, deployment, incidents, observability | [Production operations](references/production-operations.md) |
| Next.js + Supabase/Postgres projects | [Next.js + Supabase](references/nextjs-supabase.md) |
| Traceability to all nine books | [Book-to-rule map](references/book-to-rule-map.md) |

### 4. IMPLEMENT (small, cohesive steps)
- Prefer the narrowest implementation satisfying the contract. Reuse existing conventions and libraries where appropriate.
- Write or update focused tests near the change. Make a small observable increment, then test it; do not stack unrelated rewrites.
- Keep boundaries and failure handling explicit. Treat input validation and authorization as separate concerns.
- Add schema constraints where suitable; application-level checks alone are not enough for cross-request data invariants.
- Prefer reversible migrations and compatibility windows; don't discard data without explicit authorization.
- Document *why* when non-obvious. Avoid comments that merely restate code.

### 5. PROVE (evidence before "done")
Run the checks that exist in the repository; don't invent command names. L1/L2 check the relevant subset of:
- Targeted tests, negative cases, boundary cases, integration tests, and concurrency/retry tests if warranted.
- Typechecking, linting, build, schema migration validation, authorization/RLS tests, and end-to-end workflows.
- Compatibility, error handling, performance, logging hygiene, and rollback behavior when relevant.
- Diff review: no unexpected file edits, weakened tests, exposed secrets, unrelated refactoring, or accidental scope expansion.

**Never label a feature deployed/merged/production-safe solely because local tests or CI pass.** If you cannot run something, report exactly what was not run and why. Use [verification report](templates/verification-report.md).

### 6. REPORT (short, evidence based)
For L0: what changed and which check passed/wasn't run.
For L1: outcome, key design choice, files affected, tests executed/results, and remaining risk.
For L2: add security/data invariants checked, migration and rollback status, deployment state, and residual risks. State whether the user still needs to take an action. Avoid claiming completion of work that could not be verified.

## Review mode
When reviewing rather than writing code, prioritize **correctness, security, integrity, compatibility, race conditions, and regressions**, followed by design complexity and maintainability. For each finding give severity, file/line, exploit/failure scenario, and the smallest suitable fix. Avoid nitpicks that distract from substantial issues. If no findings, say so and state test/inspection limitations.

## Decision heuristics

- **Complexity is a cost:** a new abstraction should hide more complexity than it introduces.
- **Architecture follows measurable drivers:** don't optimize hypothetical scale; design for actual latency, consistency, availability, and team constraints.
- **State has ownership:** know which component owns each invariant and how all writes preserve it.
- **Transactions have boundaries:** if a multi-step effect cannot be atomic, use explicit compensation/idempotency and observable intermediate state.
- **Retries are not harmless:** make externally repeated operations idempotent or safe to duplicate.
- **Tests are design feedback:** if code is hard to test, examine coupling; don't automatically introduce elaborate interfaces.
- **Security is a property of the entire path:** UI hiding and route guards do not substitute for data-layer authorization.
- **Refactors must preserve behavior:** use tests and small transformations; separate functional change from structural cleanup when feasible.
- **Simplify by removing:** before adding a service, table, configuration option, or dependency, ask whether an existing simpler path handles the need.

## Acceptance gate
Do not conclude an L1/L2 task without answering: (1) What invariant could this change break? (2) How was it tested? (3) What happens on failure/retry? (4) Can it be understood and changed later? (5) What is still unverified?
