# Production operations and change safety

**Use for:** changes that affect deployment, live data, maintenance, rollout, incident response, or service availability.

## Release-readiness questions

- What exactly changed, and is it backward-compatible with old clients/app instances?
- Are DB migrations safe under live traffic? Is a backup or recoverability measure needed?
- Can feature behavior be disabled or rolled back? Which changes are irreversible?
- Are configuration/secrets present in the actual target environment (without exposing them)?
- What telemetry will show success, errors, unusual latency, or unauthorized access attempts?
- What resource or quota could be exhausted under burst load?
- Who has permission to deploy, inspect incidents, and recover data?

## Rollout

For consequential changes, favor feature flags, canaries, staged migration, or phased deployment **if supported by the product and justified by risk**. Never assume a branch being green means it is in production. Confirm merged commit, release artifact, deployment target, runtime configuration, and smoke-test result separately.

## Observability

Logs: structure, correlation IDs, meaningful state transitions, no secrets/PII leakage. Metrics: useful service-level indicators (error rates, latency distribution, queue age, failures), not dashboards for their own sake. Traces: where multi-hop flows require visibility. Alerts: actionable symptoms rather than noise.

## Incident posture

If production is failing, prioritize stabilization and impact assessment before cleanup. Avoid destructive actions without authority. Record observed symptoms, timeline, likely blast radius, mitigation and rollback status, and follow-up preventive tests. Distinguish hypothesis from verified root cause.

## Final state language

Use precise statuses: "implemented locally", "tested locally", "CI passed", "PR opened", "merged", "deployed to staging", "deployed to production", "verified in production". Do not conflate them.
