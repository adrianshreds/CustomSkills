# Conditional playbook: Next.js + Supabase/Postgres

**Load only when repository uses these technologies.** Inspect the installed versions, deployment model, client/server boundary, SQL migrations, actual RLS policies, and repository conventions first. Never infer framework API details solely from memory.

## Where the trust boundary lives

- Browser UI can improve experience, not enforce sensitive authorization.
- Server handlers/functions must authenticate the request and authorize the exact resource/action.
- Database RLS and constrained security-definer functions should prevent direct access bypasses where exposed clients or roles can reach the DB.
- Storage object authorization must be assessed separately from relational row policy. A record being hidden doesn't prove the blob is protected.
- Service-role operations bypass ordinary RLS: keep privileged credentials server-only and minimize the scope of queries using them.

## RLS review procedure

1. Enumerate exposed tables/views/functions, allowed roles, data classifications, and intended select/insert/update/delete actions.
2. Review actual SQL policies and function privileges; consider both USING and WITH CHECK on mutation paths.
3. Check tenant/user ownership, state transition constraints, table constraints, storage policies, and database functions together.
4. Confirm that authorization logic cannot rely on mutable or caller-controlled metadata unless independently verified.
5. Test anonymous, legitimate owner, other user, moderator, service role, and revoked users using real DB sessions/roles where feasible.
6. Inspect aggregate/derived views, search RPCs, public lists, media URL resolution, and background processing for privacy leakage.

**Security-definer functions:** inspect ownership, search path, input validation, public EXECUTE grants, row locking where concurrency matters, and whether the function expands privileges inadvertently. Do not assume RLS applies inside such functions the same way as normal client queries.

## End-to-end feature checklist

- Map request → session → authorization → domain validation → SQL/RPC → storage → event/job → response.
- Define data invariant (uniqueness, legal status transitions, ownership, provenance); enforce via DB constraint/transaction or narrow privileged RPC where appropriate.
- Make retries/replays safe: handle repeated OTP/resend, upload finalize, claim, and withdrawal commands according to domain semantics.
- For private media, authorize access at retrieval time where revocation matters; use narrowly scoped, short-lived signed URLs when appropriate; do not mistake the secrecy of a URL for durable authorization.
- Plan schema changes compatibly if old and new application versions overlap; test RLS/migrations against local Postgres/Supabase, not only TypeScript compilation.
- For Next.js SSR/server route handlers, inspect session freshness, caching behavior, cookie scope, trusted redirects and host/proxy behavior against actual framework version.
- Confirm no secret/token/private user data leaks into client bundles, public cache, logs, or build output.

## Example invariant (illustrative only)

> A private uploaded asset can be retrieved only by the owner or an explicitly authorized party under the current sharing policy. A stale search result or cached URL may not grant access after revocation beyond a documented, acceptable expiry window.

Test the owner path, unrelated-user path, unauthorized direct storage path, revoked-grant path, and concurrent authorization/revocation path as appropriate. Don't create an architecture or new service just to enforce an invariant that can be safely enforced by the existing database and storage rules.
