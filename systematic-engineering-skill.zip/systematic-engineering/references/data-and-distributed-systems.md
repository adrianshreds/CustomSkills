# Data and distributed systems

**Use for:** persistence/schema/API contracts; transactions, messages, retries, concurrency, caches, materialized views, scaling, consistency, and integration between services. Inspired particularly by the system trade-off methods discussed in *Designing Data-Intensive Applications*, 2nd edition.

## Build a state map before schema changes

Name: canonical/source-of-truth state; derived/projection state; actors permitted to modify each; state transitions; invariants and uniqueness constraints; required retention/audit; whether changes are reversible.

Example: `capture.status` is authoritative; a search result is derived. Never treat an asynchronously updated search index as the definitive basis for authorization.

## Data design

- Use explicit schema types, appropriate nullability, foreign keys, check constraints, unique constraints, indexes, and transaction isolation when needed.
- Treat every constraint as an observable contract: e.g., only one finalized claim per media asset; no invalid state transitions; no orphaned ownership record.
- Determine query shapes and access patterns **before** adding indexes. Measure slow queries; note that indexes add write and storage overhead.
- Define data lifecycles: migrations, backfills, deletion, retention, recovery, and compatibility between app versions.
- Avoid storing sensitive data or precision beyond what the feature requires.

## Concurrency and transactions

Ask: *What happens if two requests run at once? What if a client retries after a timeout? What if the process fails halfway?*

- For multi-row invariants, use a transaction with a database-enforced mechanism (conditional update, unique constraint, appropriate lock/isolation). Don't rely on read-then-write races.
- Know if your reads need linearizable/transactionally consistent values, can tolerate snapshot reads, or can use eventual consistency.
- Use idempotency keys or deduplication constraints for retried side effects; distinguish "request completed" from "response received".
- Avoid assuming exactly-once delivery. Prefer at-least-once processing **with idempotent effects**, or explicitly documented trade-offs.
- For out-of-process side effects (email, search index, notification), consider a transactional outbox if losing the side effect would break the product; understand that this adds operational complexity.

## Queues, asynchronous work, and distributed boundaries

Before introducing a queue, define:
- **Trigger:** what event or state transition creates the work?
- **Contract:** payload/schema version, idempotency identity, ownership, ordering dependencies.
- **Delivery semantics:** retries/backoff, timeout, duplicate messages, poison messages, dead-letter/reconciliation strategy.
- **Failure mode:** visibility, partial failure, manual recovery, and whether output can become stale.
- **Privacy:** no payload should expand read access beyond its original authorization.

Do not confuse asynchronous execution with guaranteed resilience. A queue can add lag, duplicated effects, and debugging burden.

## Caches, indexes, replicas, and derived data

- State what is canonical and what is derived. Ensure a full rebuild or reconciliation is possible for derived artifacts.
- Specify staleness tolerance and invalidation approach. If a stale result could leak a private object or violate an authorization change, avoid relying on the cache for authorization.
- Prefer measured, narrow caching where query and latency problems justify it.
- Plan schema changes with expand → migrate/backfill → switch readers/writers → contract, when deployed versions overlap.

## Reliability and scale estimates

Only where relevant, estimate reads/writes per second, data size, peak/burst, hot keys, retention, replication needs, and acceptable latency/availability. Label assumptions. Profile real bottlenecks instead of adopting distributed architecture by default.

## Consistency/failure matrix (L2)

| Scenario | Required outcome | Mechanism | Test |
| --- | --- | --- | --- |
| Duplicate command | One logical effect | Idempotency key or DB uniqueness | Same command twice |
| Concurrent edits | Invariant preserved | Atomic conditional write or lock | Parallel requests |
| Worker crashes | Work eventually reconciled | Durable status, retry strategy | Inject crash |
| Partial network loss | Safe recovery or retry | Timeouts, bounded retries | Simulate failure |
| Auth revoked | No future unauthorized read | Recheck at protected boundary | Revocation test |
| Old app + new schema | No breaking behavior during rollout | Compatibility strategy | Mixed-version test |

Only implement mechanisms needed by the actual risk. For one-process CRUD, a single database transaction and appropriate constraints often suffice.
