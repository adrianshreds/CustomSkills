# Domain boundaries and application patterns

**Use for:** features with nontrivial business rules, multiple adapters, transaction coordination, or hard-to-test domain logic. Based on ideas often taught in *Architecture Patterns with Python* and broader software architecture practices.

## Start with the domain language

Define entities and important operations in the user's terms, not database/UI technology names. Write invariants as enforceable statements. Keep the critical business policy close together so it cannot diverge between a web route, CLI, worker, and admin interface.

**Default design for modest apps:** route/controller → focused application function → existing database client. Add domain objects/adapters only when their separation resolves a real problem (complex invariants, multiple storage providers, duplicated logic, hard-to-test orchestration).

## Patterns to apply conditionally

- **Domain model:** valuable when business rules are complex and need independent tests. Not mandatory for simple CRUD.
- **Service/application layer:** coordinate use cases and transaction boundaries; avoid placing all domain logic in a giant service object.
- **Repository/adapter:** useful when persistence details spread across the domain or need meaningful substitution. Don't wrap each SQL call mechanically.
- **Unit of Work:** useful to make a group of changes atomic; prefer native database transactions where sufficient.
- **Domain events:** useful when multiple consequences flow from one committed state transition. Distinguish durable events from in-memory callbacks.
- **CQRS:** useful for genuinely different read/write needs, but extra duplication and eventual consistency require justification.
- **Dependency injection:** prefer simple explicit composition; avoid DI frameworks without a problem they solve.

## Boundaries and contracts

Write down what each component owns, what it is permitted to assume, input/output semantics, state transition rules, and what errors mean. Keep side effects at visible seams. Prevent cyclic domain dependencies and implicit global state when feasible.

For cross-service workflows, avoid assuming one database transaction spans multiple services. Decide whether compensation, outbox, or reconciliation is actually required, then test the failure points.
