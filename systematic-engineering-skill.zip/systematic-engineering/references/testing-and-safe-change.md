# Testing, refactoring, and safe change

**Use for:** implementing features, debugging, redesigning code without behavior change, creating tests, reviewing CI, and deciding what verification is sufficient.

## Behavior first

Define externally observable behavior and invariants as testable examples. Tests should catch meaningful regressions, not overfit implementation details. Keep fragile mocks limited; fakes or real components may better exercise cross-layer contracts. Choose the lowest test level that credibly proves the claim:

| Concern | Suggested evidence |
| --- | --- |
| Pure business rule | Fast unit test |
| DB constraint, transaction, RLS | Integration test with actual DB/policies |
| HTTP auth and validation | Request-level test |
| Multi-step user outcome | A few E2E tests |
| Retry, race, duplicate | Concurrency/fault-injection test |
| Deploy configuration | Staging smoke test or verified runtime config |

**Important:** Typecheck/build success is not evidence that authorization, transaction correctness, or runtime behavior is safe.

## Safe refactoring protocol

1. Characterize existing behavior with tests or recorded output if coverage is weak.
2. Identify the smell and the complexity you expect to remove.
3. Change structure in small steps without intentional behavior changes.
4. Run relevant tests after each step; keep diffs narrow.
5. Review public interfaces, performance assumptions, and edge behavior.
6. Only then make behavior changes, ideally in a separately reviewable unit.

When investigating a bug, reproduce → localize → explain root cause → implement minimal fix → add regression test → inspect adjacent pathways.

## Testing principles

- Prioritize intent and contract over test count. Avoid excessive test duplication.
- Do not delete/weaken assertions just to make CI green.
- Test boundary values and adversarial/unexpected input when relevant.
- Keep tests deterministic; control time, randomness, and external dependencies.
- Prefer a minimal test fixture with clearly named scenarios.
- Verify database and authorization claims against real policy enforcement, not mocked client permissions.
- Review tests for false positives and whether failures would be observable.

## Review and maintenance

Ask: Would the next engineer understand the module? Are error handling and control flow explicit? Are new abstractions genuinely reducing complexity? Are names/domain language precise? Is the change backwards-compatible? Does it create a one-off convention? Does it require new dependencies or runtime services unnecessarily?

## Evidence format

Report **exact commands** (or clear descriptions if execution used tools), observed exit status/results, and skipped checks. Distinguish local, CI, staging, and deployment evidence. A green CI result cannot prove that a PR was merged or a deployment occurred.
