# Architecture and complexity

**Use for:** choosing boundaries, redesigning modules, modifying shared APIs, adding dependencies, evaluating monolith vs services, or reviewing design.

## Architecture drivers first

1. Separate **functional requirements** (what system does) from **quality attributes** (how well: security, latency, availability, maintainability, changeability, deployability).
2. Turn vague quality goals into testable scenarios: *when [stimulus] under [conditions], the system should [response], measured by [criterion]*.
3. Include business/team/deployment constraints: expected load, operational capability, budget, delivery timeline, and migration cost.
4. Identify most important risks before choosing a style.
5. Choose the simplest design that fulfills the real drivers; record the rejected alternatives when the decision is expensive to reverse.

| Driver | Question | Consequence |
| --- | --- | --- |
| Consistency | Can users observe stale or conflicting states? | Transaction/coordination strategy |
| Availability | What happens when a dependency fails? | Fallback, redundancy, degradation |
| Latency | What percentile/operation is actually important? | Index, cache, async boundary only if justified |
| Security | Which actors may read/change which records? | Enforced authz and audit |
| Changeability | Which policies are likely to change independently? | Module boundaries and interfaces |
| Operability | Who diagnoses, rolls back, and runs this? | Monitoring, runbooks, controlled rollout |

## Complexity budget

Prefer a small number of modules with clear, stable interfaces over a large number of tiny layers. Complexity includes local complexity, cognitive load, dependency coupling, implicit behavior, branching state, configuration count, operational burden, and distributed failure modes.

**Signs of accidental complexity:** pass-through classes with no purpose, helpers that know business rules from unrelated domains, generic frameworks built for one use case, sprawling configuration, hidden side effects, duplicated business policies, deep call chains, and APIs that expose internal implementation details.

**Information hiding:** a module should hide a consequential design decision (e.g., how matching eligibility is computed), not just rename a function. Prefer interfaces that present a simple operation while owning the hard details underneath. Document what callers need to know; do not leak storage or third-party implementation unless genuinely part of the contract.

**Dependencies:** follow existing project layout. When complexity justifies separation, let domain policy depend on domain concepts, and let adapters deal with external data/APIs. Avoid circular dependencies. Don't create repository/service/interface layers solely because a pattern exists in a book.

## Design selection walkthrough

For L2:
1. List 3-5 architecturally significant requirements.
2. Sketch the current read/write path and point of ownership for state.
3. Write primary option and one alternative, each with realistic failure modes and implementation/maintenance costs.
4. Evaluate trade-offs rather than naming a supposedly universally best architecture.
5. Decide; write a one-page ADR only for decisions with lasting impact.
6. Validate via tests, measurements, a small prototype, or staged rollout as appropriate.

## Common defaults that must be justified if changed

- Prefer a modular monolith to premature microservices.
- Prefer synchronous call chains until latency/reliability requirements justify async processing.
- Prefer database constraints over hoping every caller remembers a rule.
- Prefer specific domain naming over generic abstractions.
- Prefer tested, standard functionality over custom infrastructure.
- Prefer a small rollback-able change over broad redesign.

**Anti-pattern:** automatically add a message bus, CQRS, DDD, Kafka, and cache whenever a feature touches multiple objects. Every new component needs a stated requirement it uniquely addresses.

## Architectural completion questions

- Who owns each mutable piece of state?
- Which module enforces each critical invariant?
- What must remain compatible across clients and deployments?
- Which failure is most damaging? Can it be detected and recovered?
- What added complexity is justified by an observed requirement?
