# Security and reliability

**Use for:** any authn/authz changes, private data, user uploads, account actions, public endpoints, production failures, and permission-sensitive database operations.

## Threat and failure framing

For L2 identify **assets**, actors/roles, entry points, trust boundaries, permitted actions, potential abuse, and impact. Separate authentication (who is this?) from authorization (may this actor perform this action on this specific resource?). Define failure behavior for dependency outage, malformed input, repeated requests, partial writes, and unexpected role changes.

## Default controls

- Apply least privilege and deny by default at the actual protected resource (not just the UI).
- Validate untrusted input at the boundary; ensure domain constraints where state is changed.
- Treat object-level permission and tenancy boundaries as high risk. Test cross-user and cross-tenant reads, writes, list filtering, and state transitions.
- Never place long-lived secrets in client code, logs, traces, error messages, or commit history. Use platform-managed secrets and rotate after suspected exposure.
- Restrict file uploads by ownership, content type/size, storage access, and retrieval authorization; don't trust client-provided metadata to establish ownership.
- Use safe session/cookie defaults, CSRF protections where applicable, and short-lived, purpose-scoped capabilities; verify expiry and revocation paths.
- Audit material administrative/security transitions with minimized, non-sensitive details.
- Fail closed for authorization uncertainty. For resilience, distinguish fail-safe degradation from fail-open access.

## Review every path (not just one API)

Check user route, background job, service account, migration/function, storage object path, direct DB/RPC route, listing/search projection, cache, and file URL. If one bypasses policy, the feature is not secure.

**Authorization matrix:**

| Action | Owner | Other user | Moderator/admin | Anonymous |
| --- | --- | --- | --- | --- |
| Read private object | Intended scope | Denied | Scoped, audited if appropriate | Denied |
| Modify ownership | Policy-specific | Denied | Narrowly authorized | Denied |
| Enumerate/search | Privacy-filtered | Privacy-filtered | Scoped | Public-safe only |

Customize to the actual domain; do not mechanically treat all moderators as omnipotent.

## Resilience and recovery

- Define failure domain, fallback, timeout and retry budget. Never create unbounded retries or silent infinite loops.
- Prevent cascading failures via bounded work, controlled concurrency, and circuit-breaker/fallback mechanisms **where load analysis warrants them**.
- Define durable state for multi-step workflows. Prefer explicit statuses and reconciliation to pretending a series of network calls is atomic.
- Preserve ability to disable a problematic feature and roll back or roll forward safely.
- Record structured, privacy-preserving diagnostics for failed actions; never claim success before durable commit.
- Security and availability goals may conflict: state the acceptable degraded behavior explicitly.

## Mandatory negative tests when applicable

1. Unauthenticated request rejected.
2. Wrong-role/wrong-owner request rejected.
3. List/search cannot reveal hidden object metadata.
4. Repeated, replayed, expired, malformed, and concurrent operations fail safely.
5. After revocation, old links/tokens/caches no longer authorize reads according to requirements.
6. Failed external dependency leaves recoverable state, not false success.
7. No sensitive information appears in responses/logs.

Do not label a system "secure" solely because these tests pass; security needs ongoing review and operational controls.
