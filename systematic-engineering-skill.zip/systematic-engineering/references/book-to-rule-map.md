# Source-to-principle map (original synthesis)

This is a crosswalk, **not a chapter-by-chapter summary, verbatim extract, or claim that each author endorses these exact rules**. It deliberately merges ideas, resolves trade-offs, and adapts them to coding-agent behavior. Read the books for nuance and examples.

| Book | Primary lens | Agent operational rule | Key reference |
| --- | --- | --- | --- |
| *Designing Data-Intensive Applications* (2nd ed.), Martin Kleppmann & Chris Riccomini | Storage, consistency, distribution, durability, processing | Name source-of-truth state, transaction/consistency demands, idempotency and recovery before adding queues/caches | `data-and-distributed-systems.md` |
| *A Philosophy of Software Design* (2nd ed.), John Ousterhout | Managing complexity, information hiding, module depth | Prefer simple interfaces that encapsulate hard details; avoid new abstractions that increase mental load | `architecture-and-complexity.md` |
| *Designing Software Architectures: A Practical Approach* (2nd ed.), Humberto Cervantes & Rick Kazman | Iterative, attribute-driven architecture method | Derive boundaries and choices from actual quality-attribute scenarios and constraints | `architecture-and-complexity.md` |
| *Fundamentals of Software Architecture* (2nd ed.), Mark Richards & Neal Ford | Architecture styles, coupling, trade-offs, characteristics | Compare architecture approaches honestly, including operational and change costs | `architecture-and-complexity.md` |
| *Software Engineering at Google*, Titus Winters, Tom Manshreck & Hyrum Wright | Codebase longevity, scale, testing, review | Optimize for long-lived maintainability and verified incremental changes | `testing-and-safe-change.md` |
| *Building Secure and Reliable Systems*, Heather Adkins et al. | Security/reliability throughout lifecycle | Define trust boundaries, protect data, design failures and recovery before release | `security-and-reliability.md`; `production-operations.md` |
| *Architecture Patterns with Python*, Harry Percival & Bob Gregory | Domain models, repositories, UoW, events, TDD | Introduce separation patterns only when domain complexity or testability warrants them | `domain-boundaries.md` |
| *Refactoring* (2nd ed.), Martin Fowler | Behavior-preserving restructuring | Characterize behavior; make small structural changes and rerun tests | `testing-and-safe-change.md` |
| *Growing Object-Oriented Software, Guided by Tests*, Steve Freeman & Nat Pryce | Outside-in testing and feedback from design | Use boundary tests and incremental development to discover the right interfaces | `testing-and-safe-change.md` |

## Primary/publisher/author references

- DDIA 2nd edition: https://www.oreilly.com/library/view/designing-data-intensive-applications/9781098119058/
- A Philosophy of Software Design: https://web.stanford.edu/~ouster/cgi-bin/aposd.php
- Designing Software Architectures (SEI): https://www.sei.cmu.edu/library/designing-software-architectures-a-practical-approach/
- Fundamentals of Software Architecture: https://www.oreilly.com/library/view/fundamentals-of-software/9781098175504/
- Software Engineering at Google: https://abseil.io/resources/swe-book
- Building Secure and Reliable Systems: https://sre.google/books/
- Architecture Patterns with Python: https://www.cosmicpython.com/
- Refactoring: https://refactoring.com/
- Growing Object-Oriented Software, Guided by Tests: https://growing-object-oriented-software.com/

## How to resolve apparent conflict between the books

1. **Simplicity vs extensibility:** do not create extra boundaries solely for potential reuse; introduce the smallest separation that protects an actual changing decision.
2. **Testability vs architecture overhead:** prefer a testable seam and real integration test over an application-wide abstract interface invented for one test.
3. **Consistency vs availability/latency:** state the real business invariant and document any permitted staleness; don't label eventual consistency as always "better scalability".
4. **Security vs convenience:** security invariants are hard constraints. Improve usability through narrower capabilities rather than weakening authorization.
5. **Design upfront vs learning by doing:** make a brief risk-informed plan, validate uncertain parts with small changes, and revise when evidence changes.
6. **Reliability vs complexity:** simple failure behavior is better than speculative high-availability machinery with no operational owner.
