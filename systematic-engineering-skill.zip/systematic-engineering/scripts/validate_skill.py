#!/usr/bin/env python3
"""Offline check of SKILL.md structure and local markdown references; stdlib only."""
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[1]
manifest = ROOT / "SKILL.md"
errors = []

if not manifest.is_file():
    errors.append("SKILL.md missing")
else:
    data = manifest.read_text(encoding="utf-8")
    match = re.match(r"\A---\n(.*?)\n---\n", data, re.S)
    if not match:
        errors.append("Missing YAML frontmatter")
    else:
        frontmatter = match.group(1)
        for required in ("name", "description"):
            if not re.search(rf"^{required}:\s*\S", frontmatter, re.M):
                errors.append(f"Missing {required} frontmatter key")
        name = re.search(r"^name:\s*(.+)$", frontmatter, re.M)
        if name:
            slug = name.group(1).strip()
            if len(slug) > 64 or not re.fullmatch(r"[a-z0-9]+(?:-[a-z0-9]+)*", slug):
                errors.append("Invalid skill name")
            if slug != ROOT.name:
                errors.append("Skill name does not match directory name")
        description = re.search(r"^description:\s*(.+)$", frontmatter, re.M)
        if description and len(description.group(1).strip()) > 1024:
            errors.append("Description exceeds 1024 characters")
    lines = data.splitlines()
    if len(lines) > 500:
        errors.append(f"SKILL.md too long ({len(lines)} lines)")
    for destination in re.findall(r"\[[^\]]+\]\(([^)]+)\)", data):
        if re.match(r"^[a-z]+://", destination):
            continue
        local = (ROOT / destination.split("#", 1)[0]).resolve()
        if not local.is_relative_to(ROOT.resolve()) or not local.is_file():
            errors.append(f"Broken local link: {destination}")

for required in ["README.md", "references/book-to-rule-map.md", "evals/scenarios.md"]:
    if not (ROOT / required).is_file():
        errors.append(f"Missing {required}")

if errors:
    for issue in errors:
        print(f"ERROR: {issue}", file=sys.stderr)
    sys.exit(1)
print("PASS: skill metadata, size, required files, and referenced paths")
