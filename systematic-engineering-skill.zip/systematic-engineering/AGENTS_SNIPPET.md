# Optional snippet for your repository AGENTS.md

For nontrivial software changes, use the `systematic-engineering` skill. Inspect actual code before editing; identify requirements, invariants, and test evidence. Scale process to the task: L0 small fixes, L1 features/refactors, L2 auth/data/distributed/deploy changes. Prefer simple reversible designs, real authorization, DB-enforced integrity, minimal diffs, and honest verification. Never claim a PR is merged, CI passed, or code deployed without evidence.

<!-- Do not paste the entire skill into AGENTS.md. Keep AGENTS.md short; let the skill load on demand. -->
