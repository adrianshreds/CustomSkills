# Verification report

**Change:** [brief outcome]
**State:** implemented locally | PR opened | CI passed | merged | deployed to staging | deployed to production | verified in production (list only observed stages)

## Observed evidence

| Command/check | Where | Result | Notes |
| --- | --- | --- | --- |
| [exact command or system check] | local/CI/staging/etc. | pass/fail | [key output] |

**Invariants confirmed:** [list with specific tests]
**Negative/failure cases tested:** [list]
**Unrun or blocked checks:** [what/why]
**Remaining risks:** [known gaps, assumptions, migration concerns]
**Reversal plan if applicable:** [rollback/roll-forward]
**User action required:** [only if necessary]

Do not fabricate commands or claim a stage was reached without evidence.
