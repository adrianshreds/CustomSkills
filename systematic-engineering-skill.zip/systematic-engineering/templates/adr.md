# ADR-NNN: [decision name]

**Status:** proposed | accepted | superseded
**Date:** YYYY-MM-DD
**Context and drivers:** [requirements, quality scenarios, constraints, current architecture]
**Decision:** [precise design choice and scope]
**Alternatives considered:**
- [Option A] — benefits, costs, failure modes
- [Option B] — benefits, costs, failure modes

**Reason:** [why the chosen design best meets the actual constraints]
**Consequences:** [added complexity, trade-offs, risks, monitoring, future limits]
**Compatibility/rollout:** [old clients, schema versions, flags, recovery]
**How to revisit:** [measurement or condition that would justify change]

Keep short. Create an ADR only when a decision is consequential and worth preserving for future maintainers.
