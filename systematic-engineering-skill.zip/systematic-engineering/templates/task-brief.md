# Task brief (L1/L2, use inline or as a file)

**Task:** [one sentence]
**Scope/risk level:** L1 or L2; why
**Observed repo facts:** [links/files/symbols actually inspected]
**Outcome / user-visible contract:** [what changes]
**Acceptance criteria:**
- [ ] [normal case]
- [ ] [invalid/boundary case]
- [ ] [authorization/consistency/retry case if relevant]

**Invariants:**
- [ ] [what must never happen]

**Constraints / compatibility:** [what cannot break]
**Non-goals:** [what is explicitly out of scope]
**Primary design:** [smallest coherent approach]
**Alternative / trade-off (L2):** [alternative and why rejected]
**Failure and concurrency considerations (L2):** [what happens on a retry/crash/race]
**Implementation sequence:** [small testable increments]
**Verification plan:** [actual test targets, DB/security checks, performance where justified]
**Rollout and reversal (L2):** [migration/rollback path]
**Open decisions:** [critical unanswered details, if any]
