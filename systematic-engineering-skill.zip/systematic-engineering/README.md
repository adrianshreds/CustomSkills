# Systematic Engineering — coding-agent skill

An original, actionable synthesis of software engineering lessons from nine books, packaged using the open Agent Skills `SKILL.md` convention. Designed for Cursor and Codex; generally portable to tools supporting the standard. This **does not include the books' copyrighted text** or modify an agent's model weights.

## Installation

Pick ONE host for a given repository:

**Cursor (recommended if you develop in Cursor):**

1. Unzip the download.
2. Copy the **entire** `systematic-engineering` folder into `<repo>/.cursor/skills/`.
3. Ask Cursor: `Use the systematic-engineering skill to inspect this repo and plan a safe implementation of [feature].`

**Codex:**

1. Copy the **entire** folder into `<repo>/.agents/skills/` (or `~/.agents/skills/` for personal/global use).
2. Invoke it with `$systematic-engineering` or describe an appropriate coding task. Codex can discover it from its metadata.

**General Agent Skills-compatible agents:** put the folder where that agent discovers skills; open `SKILL.md` as its entry point.

Avoid copying the entire skill into an always-on system prompt. The entry file selects reference material only when needed to reduce context and instructions overload.

## How to invoke

```text
Use systematic-engineering. Inspect the current code first; identify requirements,
contracts, invariants and risks. Choose the smallest design, implement in
verified increments, and report actual test/deploy evidence. Feature: [your task].
```

For architecture tasks:

```text
Use systematic-engineering at L2. Compare the minimal design with one viable
alternative. Focus on consistency, authorization, failure/retry behavior,
operational cost, migration and rollback. Do not code before identifying the
important invariants. Task: [your change].
```

For small bugfixes, simply invoke the skill; the L0 path intentionally avoids ceremony.

## What's inside

- `SKILL.md` — main workflow, rigor levels and dynamic reference routing.
- `references/` — architecture, complexity, data/distributed systems, domain boundaries, security, testing, operations, Next.js+Supabase (optional), all nine books mapped to rules.
- `templates/` — optional task brief, ADR, verification report.
- `evals/scenarios.md` — test cases and rubric to measure agent behavior.
- `AGENTS_SNIPPET.md` — small optional repo-level reminder.
- `scripts/validate_skill.py` — offline format, required files and link integrity checks.

## Scope and limitations

- This is a **workflow skill**, not fine-tuning or an automated compiler/security proof.
- Patterns are conditional, not mandatory. Do not enforce unnecessary complexity.
- It cannot guarantee correct architecture or security; review, tests and threat modeling still matter.
- Book ideas are synthesized and adapted; some trade-offs are intentional editorial decisions, not quotations from the authors.
- It does not operate GitHub, Linear or deployment providers unless the host agent has separately authorized tools.

## Reading/source map

See `references/book-to-rule-map.md` for all nine books and official/publisher links.

## Validation

From the skill directory:

```bash
python3 scripts/validate_skill.py
```

If the `skills-ref` CLI is installed, you can also validate with `skills-ref validate ./systematic-engineering` from the parent directory.
